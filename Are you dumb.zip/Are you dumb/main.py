import pyautogui
while true:
    a=pyautogui.confirm('Are you DUMB !! ' ,buttons=['YES','NO'])
    if a == 'YES':
        break